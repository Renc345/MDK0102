﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pr1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] A = new int[30];
            var rand = new Random();
            for (int i = 0; i < A.Length; i++)
                A[i] = rand.Next(-100, 100);

            int j = 0;
            Console.WriteLine("Сумма элементов меньших i^2 = {0}",A.Where(x => Math.Abs(x) < (j * j++)).Sum());
        }
    }
}
